function beta = compute_beta_table(n)

beta = zeros(n+1,n+1);
beta(1,1) = 1;
for i = 2:n+1
    for j=2:i
        beta(i,j) = beta(i-1,j-1) + (j-1)*beta(i-1,j);
    end
end