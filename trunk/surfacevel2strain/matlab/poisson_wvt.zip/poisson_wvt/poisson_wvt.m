
function psi = poisson_wvt(order,scale,c,x)
% psi = poisson_wvt(order,scale,c,x)
%
% order: multipole order
% scale: multipole located at exp(-scale) from the origin
% c    : [colat lon] axis of the multipole (wavelet center)
% x    : [colat lon] evaluation point (can be a N by 2 vector, for N
% points)

n = order;
a = scale;
npts = length(x);

beta = compute_beta_table(2*n+1);

theta = x(:,1)' - c(1); phi = x(:,2)' - c(2);
% now everything is centered at the north pole
xx(1,:) = sin(theta).*cos(phi); 
xx(2,:) = sin(theta).*sin(phi); 
xx(3,:) = cos(theta);
 
%mpole = exp(-a)*[sin(c(1))*cos(c(2)); sin(c(1))*sin(c(2)); cos(c(1))];  
invnorm_derivative = differentiate_invnorm(n+1,exp(-a),xx);
tmp = zeros(1,npts);
for k = 1:(n+1)
    coeff = (2*get_beta(beta,n+1,k) + get_beta(beta,n,k))*...
            exp(-k*a); 
    tmp = tmp + coeff.*invnorm_derivative(k,:);
end

% compute the L2-norm
invnorm_derivative_northpole = differentiate_invnorm(2*n+1,exp(-2*a),[0;0;1]);
tmp2 = 0;
for k = 1:(2*n+1)
    coeff2 = (2*get_beta(beta,2*n+1,k) + get_beta(beta,2*n,k))*...
            exp(-k*2*a); 
    tmp2 = tmp2 + coeff2.*invnorm_derivative_northpole(k);
end
norm = 2^(-n)*sqrt((2*a)^(2*n)*tmp2);

psi = a^n*tmp'/norm; 




