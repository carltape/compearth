
function beta = get_beta(beta_table,d,l)
% beta = get_beta(beta_table,d,l)
% 
% access function for the beta coefficients in Poisson wavelets
% See Holschneider and Iglewska-Nowak, 2007

beta = beta_table(d+1,l+1);